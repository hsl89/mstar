#!/bin/bash

sudo rm -rf build

sudo rm -rf dist

sudo rm deepspeed/git_version_info_installed.py

sudo rm -rf deepspeed.egg-info