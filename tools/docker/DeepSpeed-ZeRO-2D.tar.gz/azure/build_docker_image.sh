#!/bin/bash

docker build -t deepspeed:0.1 -f ../Dockerfile .
