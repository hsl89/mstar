import collections

import torch
from torch.cuda import Event, Stream


class save_on_cpu(torch.autograd.graph.saved_tensors_hooks):
    """Context-manager under which tensors saved by the forward pass will be
    stored on cpu, then retrieved for backward.

    When performing operations within this context manager, intermediary
    results saved in the graph during the forward pass will be moved to CPU,
    then copied back to the original device when needed for the backward pass.
    If the graph was already on CPU, no tensor copy is performed.

    Use this context-manager to trade compute for GPU memory usage (e.g.
    when your model doesn't fit in GPU memory during training).

    Args:
        pin_memory (bool): If ``True`` tensors will be saved to CPU pinned memory
                           during packing and copied to GPU asynchronously during unpacking.
                           Defaults to ``False``.
                           Also see :ref:`cuda-memory-pinning`.
        max_ongoing_copy_events (int): Since offloading to CPU is done asynchronously, enqueuing too many kernels will increase memory cost.
                                       We need to cap the maximum number of ongoing copy events to reduce the memory pressure.
                                       Defaults to ``9``.
        max_num_prefetch (int): This variable determines the maximum number of tensors we can prefetch.
                          Typically, we set it to be the number of inputs we offload to CPU at a time.
                          Defaults to ``2``.


    Example::

        >>> a = torch.randn(5, requires_grad=True, device="cuda")
        >>> b = torch.randn(5, requires_grad=True, device="cuda")
        >>> c = torch.randn(5, requires_grad=True, device="cuda")
        >>>
        >>> def f(a, b, c):
        ...     prod_1 = a * b           # a and b are saved on GPU
        ...     with deepspeed.activation_offloading.save_on_cpu():
        ...         prod_2 = prod_1 * c  # prod_1 and c are saved on CPU
        ...     y = prod_2 * a           # prod_2 and a are saved on GPU
        ...     return y
        >>>
        >>> y = f(a, b, c)
        >>> del a, b, c  # for illustration only
        >>> # the content of a, b, and prod_2 are still alive on GPU
        >>> # the content of prod_1 and c only live on CPU
        >>> y.sum().backward()  # all CPU tensors are moved back to GPU, for backward
        >>> # all intermediary tensors are released (deleted) after the call to backward

    """
    def __init__(self, pin_memory=False, max_ongoing_copy_events=9, max_num_prefetch=1):
        self.offload_stream = Stream()
        self.copy_stream = Stream()
        self.prefetch_queue = collections.deque()
        self.prefetched_dict = {}
        self.fetched_tensor_ids = set()
        self.__max_ongoing_copy_events = max_ongoing_copy_events
        self.__ongoing_copy_events: Deque[Event] = collections.deque()

        def pack_to_cpu(tensor):
            if not pin_memory or not tensor.is_cuda:
                return (None, None, tensor.device, tensor.cpu())

            current_stream = torch.cuda.current_stream()
            with torch.cuda.stream(self.offload_stream):
                while self.__ongoing_copy_events and self.__ongoing_copy_events[
                        0].query():
                    self.__ongoing_copy_events.popleft()
                if len(self.__ongoing_copy_events
                        ) > self.__max_ongoing_copy_events:
                    self.__ongoing_copy_events.popleft().synchronize()

                cpu_tensor = torch.empty(
                        tensor.size(),
                        dtype=tensor.dtype,
                        layout=tensor.layout,
                        pin_memory=(torch.cuda.is_available() and not tensor.is_sparse))
                self.offload_stream.wait_stream(current_stream)
                cpu_tensor.copy_(tensor, non_blocking=tensor.is_cuda & torch.cuda.is_available())

                event = Event()
                event.record()
                self.__ongoing_copy_events.append(event)

            tensor.record_stream(self.offload_stream)

            idx = id(cpu_tensor)
            packed = (idx, event, tensor.device, cpu_tensor)
            self.prefetch_queue.append(packed)
            return packed

        def unpack_from_cpu(packed):
            idx, event, device, tensor = packed

            if idx is None:
                return tensor.to(device)

            # fetching activations
            if idx in self.prefetched_dict:
                copy_event, unpacked = self.prefetched_dict.pop(idx)
                torch.cuda.current_stream().wait_event(copy_event)
            else:
                self.copy_stream.wait_event(event)
                with torch.cuda.stream(self.copy_stream):
                    unpacked = tensor.to(device, non_blocking=torch.cuda.is_available())
                    self.fetched_tensor_ids.add(idx)
                torch.cuda.current_stream().wait_stream(self.copy_stream)
            unpacked.record_stream(torch.cuda.current_stream())

            # prefetching activations
            while self.prefetch_queue and len(self.prefetched_dict) < max_num_prefetch:
                next_idx, next_event, next_device, next_tensor = self.prefetch_queue.pop()
                if next_idx not in self.fetched_tensor_ids:
                    with torch.cuda.stream(self.copy_stream):
                        self.copy_stream.wait_event(next_event)
                        next_unpacked_tensor = next_tensor.to(next_device, non_blocking=torch.cuda.is_available())
                        next_copy_event = Event()
                        next_copy_event.record()
                    self.prefetched_dict[next_idx] = (next_copy_event, next_unpacked_tensor)
            return unpacked

        super().__init__(pack_to_cpu, unpack_from_cpu)

