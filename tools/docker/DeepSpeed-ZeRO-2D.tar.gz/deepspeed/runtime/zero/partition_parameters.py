"""
"Copyright 2020 The Microsoft DeepSpeed Team.
Licensed under the MIT license.
"""

import json
from logging import debug
import numpy as np

from torch._C import dtype
from deepspeed.runtime.zero.utils import assert_ints_same_as_other_ranks
import os
import time
import types
from enum import Enum
import functools
import itertools
from typing import Callable, Iterable, List, Tuple

import torch
from torch import Tensor
from torch.cuda import Stream
import torch.distributed
from torch.distributed.distributed_c10d import _get_global_rank
from torch.nn import Parameter
import torch.distributed.distributed_c10d as c10d
import torch.distributed as dist

from .linear import LinearModuleForZeroStage3, LinearFunctionForZeroStage3
from .offload_constants import *

from ..utils import info_rank_0, see_memory_usage, get_only_unique_item
from deepspeed.utils import log_dist, init_distributed, instrument_w_nvtx
from deepspeed.utils.debug import debug_param2name_id_shape, debug_param2name_id_shape_device, debug_module2name, debug_param2name, debug_param2name_id_shape_status, printflock, log_rank_file

from ..swap_tensor.partitioned_param_swapper import AsyncPartitionedParameterSwapper, PartitionedParamStatus
from ..config import DeepSpeedConfig

param_count = 0
partitioned_param_data_shape = [1]


def print_rank_0(message, debug=False, force=False):
    rank = torch.distributed.get_rank()
    if rank == 0 and (debug or force):
        print(message)
    # other variations
    # - print for all ranks w/o interleaving
    # printflock(f"[{rank}] {message}")
    # - print to log file per rank
    # log_rank_file(rank, message)


def is_zero_param(parameter):
    if not torch.is_tensor(parameter):
        return False
    return hasattr(parameter, 'ds_id')


def _init_external_params(module):
    if not hasattr(module, '_external_params'):
        module._external_params = {}

        def external_parameters(self):
            return self._external_params.items()

        def all_parameters(self):
            return itertools.chain(self.named_parameters(self,
                                                         recurse=False),
                                   external_parameters(self))

        module.ds_external_parameters = types.MethodType(external_parameters, module)
        module.all_parameters = types.MethodType(all_parameters, module)


def register_external_parameter(module, parameter):
    """Instruct DeepSpeed to coordinate ``parameter``'s collection and partitioning in
    the forward and backward passes of ``module``.

    This is used when a parameter is accessed outside of its owning module's
    ``forward()``. DeepSpeed must know to collect it from its partitioned
    state and when to release the memory.

    .. note::
        This is only applicable to training with ZeRO stage 3.

    Args:
        module (``torch.nn.Module``): The module that requires ``parameter`` in its forward pass.
        parameter (``torch.nn.Parameter``): The parameter to register.

    Raises:
        RuntimeError: If ``parameter`` is not of type ``torch.nn.Parameter``.


    Examples
    ========

    #. Register a weight that is used in another module's forward pass (line 6).
       Parameter ``layer1.weight`` is used by ``layer2`` (line 11).

        .. code-block:: python
            :linenos:
            :emphasize-lines: 6,11

            class ModuleZ3(torch.nn.Module):
                def __init__(self, *args):
                    super().__init__(self, *args)
                    self.layer1 = SomeLayer()
                    self.layer2 = OtherLayer()
                    deepspeed.zero.register_external_parameter(self, self.layer1.weight)

                def forward(self, input):
                    x = self.layer1(input)
                    # self.layer1.weight is required by self.layer2.forward
                    y = self.layer2(x, self.layer1.weight)
                    return y
    """
    if not isinstance(parameter, torch.nn.Parameter):
        raise RuntimeError('Parameter is not a torch.nn.Parameter')

    if not hasattr(module, '_external_params'):
        _init_external_params(module)

    key = id(parameter)
    module._external_params[key] = parameter


def unregister_external_parameter(module, parameter):
    """Reverses the effects of :meth:`register_external_parameter`.

    Args:
        module (``torch.nn.Module``): The module to affect.
        parameter (``torch.nn.Parameter``): The parameter to unregister.

    Raises:
        RuntimeError: If ``parameter`` is not of type ``torch.nn.Parameter``.
        RuntimeError: If ``parameter`` is not a registered external parameter of ``module``.
    """
    if not isinstance(parameter, torch.nn.Parameter):
        raise RuntimeError('Parameter is not a torch.nn.Parameter')

    if not hasattr(module,
                   '_external_params') or id(parameter) not in module._external_params:
        raise RuntimeError('Parameter is not a registered external parameter of module.')

    key = id(parameter)
    del module._external_params[key]


class ZeroParamType(Enum):

    # same as regular pytorch parameters
    NORMAL = 1

    # parameters are partitioned across data parallel process
    PARTITIONED = 2

    # the parameter is held with a unique process rank
    # and is not available on all other process
    REMOTE = 3


class ZeroParamStatus(Enum):
    # parameters are fully present and ready for use on all processes
    AVAILABLE = 1

    # parameters are either partitioned or remote in some or all process
    NOT_AVAILABLE = 2

    # parameters are being gathered.
    INFLIGHT = 3


_orig_torch_empty = torch.empty
_orig_torch_zeros = torch.zeros
_orig_torch_ones = torch.ones
_orig_torch_full = torch.full


def wrapper_for_cuda_tensor(fn: Callable, target_fp_dtype: torch.dtype = None) -> Callable:
    def wrapped_fn(*args, **kwargs):
        if kwargs.get("device", None) is None:
            kwargs['device'] = torch.device('cuda:{}'.format(os.environ["LOCAL_RANK"]))
        tensor = fn(*args, **kwargs)
        if tensor.is_floating_point() and target_fp_dtype is not None:
            tensor = tensor.to(target_fp_dtype)
        return tensor
    return wrapped_fn


def get_empty_cuda_tensor_fn_for_dtype(dtype: torch.dtype = None) -> Callable:
    def empty_cuda_tensor(*size, **kwargs):
        if kwargs.get("device", None) is None:
            kwargs['device'] = torch.device('cuda:{}'.format(os.environ["LOCAL_RANK"]))
        tensor = _orig_torch_empty(*size, **kwargs)
        if tensor.is_floating_point() and dtype is not None:
            tensor = tensor.to(dtype)
        return tensor
    return empty_cuda_tensor


def get_new_cuda_tensor_fn_for_dtype(dtype: torch.dtype = None) -> Callable:
    def new_cuda_tensor(cls, *args):
        device = torch.device('cuda:{}'.format(os.environ["LOCAL_RANK"]))
        tensor = torch.ones((1, 1), device=device).new_empty(*args)
        if tensor.is_floating_point() and dtype is not None:
            tensor = tensor.to(dtype)
        return tensor
    return new_cuda_tensor


# https://stackoverflow.com/a/63851681/9201239
def get_all_subclasses(cls):
    subclass_list = []

    def recurse(cl):
        for subclass in cl.__subclasses__():
            subclass_list.append(subclass)
            recurse(subclass)

    recurse(cls)

    return set(subclass_list)


@instrument_w_nvtx
def free_param(param: Parameter) -> None:
    """Free underlying storage of a parameter."""
    assert not param.ds_active_sub_modules, param.ds_summary()
    # param.data doesn't store anything meaningful in partitioned state
    if param.data.is_cuda:
        # need to make sure that we don't free the parameter while it is still
        # being used for computation
        param.data.record_stream(torch.cuda.current_stream())
    param.data = torch.empty(1, dtype=param.dtype, device=param.device)
    param.ds_status = ZeroParamStatus.NOT_AVAILABLE


reuse_buffers = False
temp_contiguous_tensor = None
empty_buffers = {}


# Inserts _post_init_method at the end of init method
# for all sub classes of torch.nn.Module
class InsertPostInitMethodToModuleSubClasses(object):
    def __init__(self, enabled=True, mem_efficient_linear=True, config=None, dtype=None):
        self.mem_efficient_linear = mem_efficient_linear
        self.enabled = enabled
        self._set_dtype(config, dtype)
        assert self.dtype in [torch.half, torch.bfloat16, torch.float], f"Invalid data type {self.dtype}, allowed values are [torch.half, torch.bfloat16, torch.float]"

        def load_with_ds_tensor(fn_to_load: Callable) -> Callable:
            """replace param.data with param.ds_tensor before calling _load_from_state_dict function.
            takes the following steps:
            1. set param.data to param.ds_tensor
            2. calls the original function
            3. reset param.data to the scalar tensor
            """
            @functools.wraps(fn_to_load)
            def wrapped_fn_to_load(module_to_load_fn_to: torch.nn.Module, *args, **kwargs) -> None:
                params_to_load_fn_to: Iterable[Parameter] = list(
                        sorted(module_to_load_fn_to.parameters(recurse=False),
                               key=lambda p: p.ds_id))

                for param in params_to_load_fn_to:
                    param.data = param.ds_tensor.data

                fn_to_load(module_to_load_fn_to, *args, **kwargs)

                for param in params_to_load_fn_to:
                    param.data = torch.empty(1, dtype=param.dtype, device=param.device)
                    param.ds_status = ZeroParamStatus.NOT_AVAILABLE

            return wrapped_fn_to_load

        torch.nn.modules.module.Module._old_load_from_state_dict = torch.nn.modules.module.Module._load_from_state_dict
        torch.nn.modules.module.Module._load_from_state_dict = load_with_ds_tensor(
                torch.nn.modules.module.Module._old_load_from_state_dict)

    def __enter__(self):
        if not self.enabled:
            return
        
        def apply_with_gather(orig_module_apply_fn: Callable) -> Callable:
            """many models make use of child modules like Linear or Embedding which
            perform their own weight initialization in their __init__ methods,
            but will then have more weight initialization in a parent module's __init__
            method that modifies weights of child modules, which is typically done
            using the Module.apply method.
            since the Init context manager partitions child modules immediately after
            they are initialized, without modifying apply we would entirely skip
            any initialization done by parent modules.
            to get around this issue, we wrap the function passed to Module.apply
            so that the applied function is applied to child modules correctly.
            """
            def get_wrapped_fn_to_apply(fn_to_apply: Callable) -> Callable:
                if hasattr(fn_to_apply, "wrapped"):
                    return fn_to_apply

                @functools.wraps(fn_to_apply)
                def wrapped_fn_to_apply(module_to_apply_fn_to: torch.nn.Module) -> None:
                    """gathers parameters before calling apply function. afterwards
                    parameters are broadcasted to ensure consistency across all ranks
                    then re-partitioned.
                    takes the following steps:
                    1. allgathers parameters for the current module being worked on
                    2. calls the original function
                    3. broadcasts root rank's parameters to the other ranks
                    4. re-partitions the parameters
                    """
                    params_to_apply_fn_to: Iterable[Parameter] = list(
                        sorted(module_to_apply_fn_to.parameters(recurse=False),
                               key=lambda p: p.ds_id))

                    if params_to_apply_fn_to:
                        handles = params_to_apply_fn_to[0].all_gather(params_to_apply_fn_to, async_op=True)
                        for param, handle in filter(lambda x: x[0].ds_status == ZeroParamStatus.INFLIGHT,
                                                          zip(params_to_apply_fn_to, handles)):
                            handle.wait()
                            param.ds_status = ZeroParamStatus.AVAILABLE

                    fn_to_apply(module_to_apply_fn_to)

                    for param in params_to_apply_fn_to:
                        if param.ds_process_group != torch.distributed.group.WORLD and \
                            param.ds_process_group != None:
                            print(f"WARNING broadcast initalized parameters with in the sub-group")
                        torch.distributed.broadcast(param.data,
                                                    0,
                                                    group=param.ds_process_group)

                    for param in params_to_apply_fn_to:
                        param.partition(has_been_updated=True)

                wrapped_fn_to_apply.wrapped = True
                return wrapped_fn_to_apply

            @functools.wraps(orig_module_apply_fn)
            def wrapped_apply(module: torch.nn.Module, fn_to_apply: Callable) -> None:
                orig_module_apply_fn(module, get_wrapped_fn_to_apply(fn_to_apply))

            return wrapped_apply

        def partition_after(f):
            @functools.wraps(f)
            def wrapper(module, *args, **kwargs):

                # important logic: We want to run post_init only after child's __init__ is
                # completed, and do nothing after __init__ of any of its parents and grandparents in
                # the inheritance ancestry. This way the partitioning will need to happen only once
                # when the whole object is ready to be partitioned and not before. This is because
                # often the child module will need to tweak the weights - for example running a
                # custom weights init function. So if a parent created the weights param, the child
                # won't need to gather it in order to tweak it

                print_rank_0(f'Before initializing {module.__class__.__name__}',
                             force=False)

                is_child_module = False
                if not hasattr(module, "_ds_child_entered"):
                    # child's __init__ was called, since parents all see the same object they can now skip post_init
                    is_child_module = True
                    setattr(module, "_ds_child_entered", True)

                f(module, *args, **kwargs)
                # debug output of module params
                # for param in module.parameters():
                #     print_rank_0(f'After initializing param {param.data.detach().cpu().numpy().tolist()}', debug=True)

                if is_child_module:
                    # child's __init__ is done, now we can run a single post_init on the child object
                    delattr(module, "_ds_child_entered")

                    print_rank_0(f'Running post_init for {module.__class__.__name__}',
                                 force=False)
                    # convert data type
                    if self.dtype == torch.half or self.dtype == torch.bfloat16:
                        module.to(dtype=self.dtype)

                    self._post_init_method(module)

                print_rank_0(
                    f'After initializing followed by post init for {module.__class__.__name__}',
                    force=False)

            return wrapper

        def _enable_class(cls):
            cls._old_init = cls.__init__
            cls.__init__ = partition_after(cls.__init__)

        def _init_subclass(cls, **kwargs):
            cls.__init__ = partition_after(cls.__init__)

        # Replace .__init__() for all existing subclasses of torch.nn.Module recursively
        for subclass in get_all_subclasses(torch.nn.modules.module.Module):
            # print(f"subclass={subclass.__module__}.{subclass.__qualname__}")
            _enable_class(subclass)

        # holding on to the current __init__subclass__ for exit
        torch.nn.modules.module.Module._old_init_subclass = torch.nn.modules.module.Module.__init_subclass__
        torch.nn.modules.module.Module._old_apply = torch.nn.modules.module.Module.apply
        torch.Tensor.__old_new__ = torch.Tensor.__new__

        # Replace .__init__() for future subclasses of torch.nn.Module
        torch.nn.modules.module.Module.__init_subclass__ = classmethod(_init_subclass)
        torch.nn.modules.module.Module.apply = apply_with_gather(
            torch.nn.modules.module.Module._old_apply)

        torch.Tensor.__new__ = get_new_cuda_tensor_fn_for_dtype(self.dtype)
        torch.empty = get_empty_cuda_tensor_fn_for_dtype(self.dtype)
        torch.zeros = wrapper_for_cuda_tensor(_orig_torch_zeros, self.dtype)
        torch.ones = wrapper_for_cuda_tensor(_orig_torch_ones, self.dtype)
        torch.full = wrapper_for_cuda_tensor(_orig_torch_full, self.dtype)

        if self.mem_efficient_linear:
            print_rank_0(
                "nn.functional.linear has been overridden with a more memory efficient version. This will persist unless manually reset.",
                force=True)
            self.linear_bk = torch.nn.functional.linear
            torch.nn.functional.linear = LinearFunctionForZeroStage3.apply

    def __exit__(self, exc_type, exc_value, traceback):
        if not self.enabled:
            return

        def _disable_class(cls):
            cls.__init__ = cls._old_init

        # Replace .__init__() for all existing subclasses of torch.nn.Module
        for subclass in get_all_subclasses(torch.nn.modules.module.Module):
            _disable_class(subclass)

        # Replace .__init__() for future subclasses of torch.nn.Module
        torch.nn.modules.module.Module.__init_subclass__ = torch.nn.modules.module.Module._old_init_subclass
        torch.nn.modules.module.Module.apply = torch.nn.modules.module.Module._old_apply

        torch.Tensor.__new__ = torch.Tensor.__old_new__
        torch.empty = _orig_torch_empty
        torch.zeros = _orig_torch_zeros
        torch.ones = _orig_torch_ones
        torch.full = _orig_torch_full

        #un doing it here will undo it during training
        #if self.mem_efficient_linear:
        #    torch.nn.functional.linear = self.linear_bk
        #        if self.mem_efficient_linear:
        #            torch.nn.functional.linear = self.linear_bk

        # Now that we cleaned up the metaclass injection, raise the exception.
        if exc_type is not None:
            return False

    # To be implemented by inheriting classes
    def _post_init_method(self, module):
        pass

    def _set_dtype(self, ds_config, dtype):
        if ds_config is not None and dtype is None:
            _ds_config = DeepSpeedConfig(ds_config)
            if _ds_config.bfloat16_enabled and _ds_config.fp16_enabled:
                raise RuntimeError("bfloat16 and fp16 cannot be enabled at once")

            if _ds_config.bfloat16_enabled:
                self.dtype = torch.bfloat16
            elif _ds_config.fp16_enabled:
                self.dtype = torch.half
            else:
                self.dtype = torch.float
        else:
            self.dtype = dtype or torch.half


class AllGatherCoalescedHandle:
    def __init__(self,
                 handle,
                 params: list,
                 partitions: list,
                 world_size: int,
                 comm_stream: Stream,
                 split_launch=False,
                 launch_group=None) -> None:
        self.__handle = handle
        self.__params = params
        self.__partitions = partitions
        self.__world_size = world_size
        self.__comm_stream = comm_stream
        self.__complete = False
        self.__split_launch = split_launch
        self.__launch_group = launch_group

        for param in self.__params:
            if param.ds_status != ZeroParamStatus.INFLIGHT:
                raise RuntimeError(
                    f"expected param {param.ds_summary()} to not be available")

    @instrument_w_nvtx
    def wait(self) -> None:
        if self.__complete:
            return

        with torch.cuda.stream(torch.cuda.current_stream()):
            instrument_w_nvtx(self.__handle.wait)()  # wait for the allgather to complete

            if self.__split_launch:
                for _, param in enumerate(self.__params):
                    assert param.ds_status == ZeroParamStatus.INFLIGHT, f"expected param {param.ds_summary()} to be inflight"
                    param.ds_status = ZeroParamStatus.AVAILABLE

                self.__complete = True

                return
            # split the single tensor out into individual tensors
            param_offset = 0
            for param in self.__params:
                assert param.ds_status == ZeroParamStatus.INFLIGHT, f"expected param {param.ds_summary()} to be inflight"
                partitions = []
                for rank in range(self.__world_size):
                    param_start = rank * param.ds_tensor.ds_numel
                    if param_start < param.ds_numel:
                        part_to_copy = self.__partitions[rank].narrow(
                            0,
                            param_offset,
                            min(param.ds_numel - param_start,
                                param.ds_tensor.ds_numel))
                        partitions.append(part_to_copy)

                replicated_tensor = instrument_w_nvtx(torch.cat)(partitions).view(
                    param.ds_shape)

                param.data = replicated_tensor.data
                param.ds_status = ZeroParamStatus.AVAILABLE

                for part_to_copy in partitions:
                    part_to_copy.record_stream(torch.cuda.current_stream())

                param_offset += param.ds_tensor.ds_numel

            self.__complete = True
            torch.cuda.default_stream().wait_stream(torch.cuda.current_stream())


# Replaces all parameters in module with Scattered Parameters
class Init(InsertPostInitMethodToModuleSubClasses):
    param_id = 0

    def __init__(self,
                 module=None,
                 data_parallel_group=None,
                 mem_efficient_linear=True,
                 remote_device=None,
                 pin_memory=False,
                 config=None,
                 enabled=True,
                 dtype=None,
                 ds_config=None):
        """A context to enable massive model construction for training with
        ZeRO-3. Models are automatically partitioned (or, sharded) across the
        system and converted to half precision.

        Args:
            module (``torch.nn.Module``, optional): If provided, partition the model as
                if it was constructed in the context.
            data_parallel_group (``torch.distributed`` process group, optional):
                The group of processes to partition among. Defaults to all processes.
            mem_efficient_linear (bool, optional): Replace
                torch.nn.functional.linear with an implementation that allows
                DeepSpeed to partition parameters. Defaults to ``True``.
            remote_device (string, optional): The initial device to store model
                weights e.g., ``cpu``, ``nvme``. Passing ``"cpu"`` will create the model in CPU
                memory. The model may still be moved to GPU based on the
                offload settings for training. Defaults to the local GPU.
            pin_memory (bool, optional): Potentially increase performance by
                using pinned memory for model weights. ``remote_device`` must be
                ``"cpu"``. Defaults to ``False``.
            config (``json file`` or dict, optional): If provided, provides configuration
                for swapping fp16 params to NVMe.
            enabled (bool, optional): If ``False``, this context has no
                effect. Defaults to ``True``.
            dtype (``dtype``, optional): Can be used to change the data type of the parameters.
                Supported options are ``torch.half`` and ``torch.float``. Defaults to ``None``

        This context accelerates model initialization and enables models that
        are too large to allocate in their entirety in CPU memory. It has the
        following effects:

        #. allocates tensors to either GPU or CPU memory or NVMe
        #. converts floating point tensors to half precision
        #. immediately partitions tensors among the group of data-parallel devices
        #. (*optional*) replaces ``torch.nn.functional.linear`` with a more
           memory-efficient implementation

        These modifications allow for models that exceed the size of local CPU/GPU
        memory/NVMe, but fit within the total NVMe capacity (*i.e.*, aggregate CPU
        or GPU memory or NVMe) across all nodes. Consider initializing a model with one
        trillion parameters, whose weights occupy two terabytes (TB) in half
        precision. The initial CPU allocation in full precision requires 4TB of
        memory *per process*, and so a system with 8 GPUs per node would need 32TB of
        CPU memory due to data-parallel redundancies. Instead, by immediately
        partitioning tensors we remove the redundancies. The result is that
        regardless of the number of GPUs, we still only require the original 4TB. This
        allows for a linear increase in model size with the aggregate system memory.
        For example, if a node has 1TB of memory and 8 GPUs, we could fit a trillion
        parameter model with 4 nodes and 32 GPUs.

        Important: If the fp16 weights of the model can't fit onto a single GPU memory
        this feature must be used.

        .. note::
            Initializes ``torch.distributed`` if it has not already been done so.
            See :meth:`deepseed.init_distributed` for more information.

        .. note::
            Can also be used as a decorator:

            .. code-block:: python

                @deepspeed.zero.Init()
                def get_model():
                    return MyLargeModel()

        .. note::
            Only applicable to training with ZeRO-3.

        Examples
        --------

        #. Allocate a model and partition it among all processes:

            .. code-block:: python

                with deepspeed.zero.Init():
                    model = MyLargeModel()


        #. Allocate a model in pinned CPU memory and partition it among a subgroup of processes:

            .. code-block:: python

                with deepspeed.zero.Init(data_parallel_group=mpu.get_data_parallel_group(),
                                         remote_device="cpu",
                                         pin_memory=True):
                    model = MyLargeModel()


        #. Partition an already-allocated model in CPU memory:

            .. code-block:: python

                model = deepspeed.zero.Init(module=model)
        """

        super().__init__(enabled=enabled,
                         mem_efficient_linear=mem_efficient_linear,
                         config=config,
                         dtype=dtype)
        if not torch.distributed.is_initialized():
            init_distributed()
            assert torch.distributed.is_initialized(), "Parameters cannot be scattered without initializing torch.distributed"
        if data_parallel_group is None:
            self.ds_process_group = torch.distributed.group.WORLD
        else:
            self.ds_process_group = data_parallel_group

        self.rank = torch.distributed.get_rank(group=self.ds_process_group)
        self.world_size = torch.distributed.get_world_size(group=self.ds_process_group)

        #Local device is the device where the parameters are consumed
        #It is the device where parameters are fully instantiated using allgather
        self.local_device = torch.device('cuda:{}'.format(os.environ["LOCAL_RANK"]))

        # because this Init will be invoked in two ways
        # using with statement or called by stage3-optimizer
        _ds_config = ds_config if ds_config is not None else DeepSpeedConfig(config)

        self.local_shard: bool = _ds_config.zero_config.zero2d_local_shard
        self.zero2d_shard_size = _ds_config.zero_config.zero2d_shard_size
        # get the hierarchy all-gather flag from 
        self.hierarchy_allgather:bool = _ds_config.zero_config.zero2d_hierarchy_allgather
        print(f'partition parameters context: local shard {self.local_shard}, '
              f'shard_size "{self.zero2d_shard_size}", '
              f'hierarchy all-gather {self.hierarchy_allgather}')

        self.ds_param_shard_group = self.ds_process_group  # default to all ranks
        self.ds_param_shard_size = self.world_size  # default with world-size
        self.ds_param_repli_group = None
        self.ds_param_repli_size = None
        if self.local_shard:
            self._create_shard_groups(data_parallel_group)

        self._validate_remote_device(remote_device, config)

        #Remote device is the device where parameter partiitons are stored
        #It can be same as local_device or it could be CPU or NVMe.
        self.remote_device = self.local_device if remote_device is None else remote_device
        self.pin_memory = pin_memory if (
            self.remote_device == OFFLOAD_CPU_DEVICE) else False

        # Enable fp16 param swapping to NVMe
        if self.remote_device == OFFLOAD_NVME_DEVICE:
            _ds_config = DeepSpeedConfig(config)
            self.param_swapper = AsyncPartitionedParameterSwapper(_ds_config)
        else:
            self.param_swapper = None

        # If we are provided an already-allocated module to prepare.
        if module is not None:
            assert isinstance(module, torch.nn.Module)
            for param in module.parameters(recurse=True):
                if is_zero_param(param):
                    continue
                self._convert_to_deepspeed_param(param)
                param.partition()

        # this have to be default stream to make the all_gather synchronize properly 
        self.comm_stream = None
    
    def __default_local_shard(self):
        """
        shard to local GPUs by default
        """
        local_rank = int(os.environ["LOCAL_RANK"])
        n_devices = torch.cuda.device_count()
        node_rank = self.rank // n_devices
        nnodes = dist.get_world_size() // n_devices
        # create param shard group
        for node_k in range(nnodes):
            # for each node create the shard group
            # all ranks must participant this process
            offset = node_k * n_devices
            shard_ranks_k = [offset + i for i in range(n_devices)]
            shard_group_k = dist.new_group(shard_ranks_k, backend='nccl')
            dist.barrier()

            if node_k == node_rank:
                self.ds_param_shard_group = shard_group_k
                self.ds_param_shard_size = n_devices
                print(
                    f'rank {dist.get_rank()}, shard group {dist.get_rank(group=shard_group_k)}/{dist.get_world_size(group=shard_group_k)}'
                )

        # create ds_param replicate group
        # assume param and gradient sharded in same group
        if nnodes > 1:
            for dev_k in range(n_devices):
                # create all groups; save the one k == local_rank
                replicate_ranks_k = [dev_k + g * n_devices for g in range(nnodes)]
                replicate_group_k = dist.new_group(replicate_ranks_k, backend='nccl')
                dist.barrier()
                if dev_k == local_rank:
                    self.ds_param_repli_group = replicate_group_k
                    self.ds_param_repli_size = len(replicate_ranks_k)
                    print(
                        f'rank {dist.get_rank()}, replicate group {dist.get_rank(group=replicate_group_k)}/{dist.get_world_size(group=replicate_group_k)}'
                    )
        else:
            self.ds_param_repli_group = None
            self.ds_param_repli_size = 1
            print(
                f'rank {dist.get_rank()}, replicate group 0/1'
            )

        self.world_size = dist.get_world_size(group=self.ds_param_shard_group)
        assert self.world_size == n_devices

    def __create_groups_from_config(self, shard_size):
        """
        create shard-group, replicate-group from config_file
        TODO: consider broadcast the config from rank0
        """
        def _sizes_all_same(groups):
            """all groups have same length"""
            all_same = True
            for g in groups:
                if len(g) != len(groups[0]):
                    return False
            return all_same
        
        def _generate_config(world_size, shard_size):
            """"""
            config = {}
            shard_groups = np.arange(world_size).reshape(-1, shard_size)
            replicate_groups = [shard_groups[:, i].tolist() for i in range(shard_size)]
            config['replicate_groups'] = replicate_groups
            config['shard_groups'] = shard_groups.tolist()
            # the environment used for debugging
            # by default use the device count
            ndevices_per_node = int(os.environ.get("NDEV_PER_NODE", torch.cuda.device_count()))
            config["span_nodes"] = len(shard_groups[0]) // ndevices_per_node
            return config
            
        config = _generate_config(dist.get_world_size(), shard_size)
        ranks_of_shard_group = config['shard_groups']
        ranks_of_repli_group = config['replicate_groups']
        if len(ranks_of_repli_group) == 0:
            assert len(ranks_of_shard_group) == 1, "replicate groups are empty only for single shard group"
            for r in ranks_of_shard_group[0]:
                ranks_of_repli_group.append([r])

        # for simplicity
        assert _sizes_all_same(ranks_of_repli_group), "replicate groups must have the same size"
        assert _sizes_all_same(ranks_of_shard_group), "shard groups must have the same size"
        
        assert sum([len(g) for g in ranks_of_shard_group]) == dist.get_world_size(), "all sharded ranks "
        if len(ranks_of_shard_group) > 1: # if only shard on one group then no need for replicate groups
            assert len(ranks_of_shard_group) == len(ranks_of_repli_group[0]), "number of shard groups must equal to the size of each replicate group"

        # global rank
        rank = dist.get_rank()
        # create shard groups
        for shard_ranks in ranks_of_shard_group:
            _group = dist.new_group(shard_ranks, backend='nccl')
            if rank in shard_ranks:
                self.ds_param_shard_group = _group
                self.ds_param_shard_size = len(shard_ranks)
                print(
                    f'rank {rank}, shard group'
                    f' {dist.get_rank(group=_group)}/{dist.get_world_size(group=_group)}'
                )

        # create replicate groups
        for repli_ranks in ranks_of_repli_group:
            if len(repli_ranks) > 1:
                _group = dist.new_group(repli_ranks, backend='nccl')
                if rank in repli_ranks:
                    self.ds_param_repli_group = _group
                    self.ds_param_repli_size = len(repli_ranks)
                    print(
                        f'rank {rank} '
                        f'replicate group {dist.get_rank(group=_group)}/{dist.get_world_size(group=_group)}'
                    )
            else:
                self.ds_param_repli_group = None
                self.ds_param_repli_size = 1
                print(f'rank {rank} replicate group 0/1')

        # assign shard group size as world size
        self.world_size = dist.get_world_size(group=self.ds_param_shard_group)
        assert self.world_size == len(ranks_of_shard_group[0])

        self.intra_all_gather_group = None
        self.inter_all_gather_group = None
        if self.hierarchy_allgather:
            # create hierarchy inter-node, intra-node groups
            # n_span_nodes = config['shard_span']
            n_span_nodes = config['span_nodes']
            assert n_span_nodes > 1, "sharding spans on single node, no need for hierarchy allgather"
            assert len(ranks_of_shard_group[0]) % n_span_nodes == 0

            n_gpu_per_node = len(ranks_of_shard_group[0]) // n_span_nodes
            intra_node_ranks_group = []
            inter_node_ranks_group = []
            for shard_group in ranks_of_shard_group:
                _intra_node_ranks = []
                for i in range(0, len(shard_group), n_gpu_per_node):
                    _intra_node_ranks.append(shard_group[i:i+n_gpu_per_node])
                _inter_node_ranks = []
                for i in range(n_gpu_per_node):
                    _ranks = [_g[i] for _g in _intra_node_ranks]
                    _inter_node_ranks.append(_ranks)

                intra_node_ranks_group.append(_intra_node_ranks)
                inter_node_ranks_group.append(_inter_node_ranks)
            print_rank_0(f"create for hierarchy all-gather groups: intra nodes {intra_node_ranks_group}", debug=True)
            print_rank_0(f"create for hierarchy all-gather groups: inter nodes {inter_node_ranks_group}", debug=True)

            # creat communicators
            for shard_group in intra_node_ranks_group:
                for intra_node_ranks in shard_group:
                    _group = dist.new_group(intra_node_ranks, backend='nccl')
                    if rank in intra_node_ranks:
                        self.intra_all_gather_group = _group
                    print_rank_0(f'create group for intra node ranks {intra_node_ranks}', debug=True)
            for shard_group in inter_node_ranks_group:
                for inter_node_ranks in shard_group:
                    _group = dist.new_group(inter_node_ranks, backend='nccl')
                    if rank in inter_node_ranks:
                        self.inter_all_gather_group = _group
                    print_rank_0(f'create group for inter node ranks {inter_node_ranks}', debug=True)
                    
    def _create_shard_groups(self, data_parallel_group):

        print(f'rank {self.rank} enable local shard at partition parameters Init')
        assert data_parallel_group is None, "data_parallel_group should be None, when local_shard is set"

        print_rank_0(f'shard size {self.zero2d_shard_size}', force=True)
        if self.zero2d_shard_size <= 0:
            self.__default_local_shard()
            if self.rank == 0:
                print('created shard groups and replicate groups on local GPUs')
        else:
            self.__create_groups_from_config(self.zero2d_shard_size)
            if self.rank == 0:
                print(f'created shard groups and replicate groups based on shard size {self.zero2d_shard_size}')

    def _validate_remote_device(self, remote_device, ds_config):
        if ds_config is not None:
            _ds_config = DeepSpeedConfig(ds_config)
            if remote_device in [None, OFFLOAD_CPU_DEVICE]:
                if _ds_config.zero_config.offload_param is not None:
                    offload_param_device = _ds_config.zero_config.offload_param[
                        OFFLOAD_PARAM_DEVICE]
                    assert offload_param_device != OFFLOAD_NVME_DEVICE, \
                    f"{OFFLOAD_PARAM_DEVICE} in DeepSpeed Config cannot be {offload_param_device} if remote device is {remote_device}."

            if remote_device == OFFLOAD_NVME_DEVICE:
                assert _ds_config.zero_config.offload_param is not None, \
                f'{OFFLOAD_PARAM} must be defined in DeepSpeed Config if remote device is {OFFLOAD_NVME_DEVICE}.'

                assert _ds_config.zero_config.offload_param[OFFLOAD_PARAM_NVME_PATH] is not None, \
                f'{OFFLOAD_PARAM_NVME_PATH} in DeepSpeed Config cannot be None if remote device is {OFFLOAD_NVME_DEVICE}'

    def _post_init_method(self, module):
        #see_memory_usage(f"Before converting parmas in {module.__class__.__name__}", force=False)
        print_rank_0(f'Converting Params in {module.__class__.__name__}', force=False)
        see_memory_usage(
            f"Before converting and partitioning parmas in {module.__class__.__name__}",
            force=False)

        global param_count
        for param_name, param in module.named_parameters(recurse=False):
            param_count += param.numel()
            if not is_zero_param(param):
                # print_rank_0(f'param before convert to deepspeed param {param_name} {param}', True)
                self._convert_to_deepspeed_param(param)
                print_rank_0(
                    f"Partitioning param {debug_param2name_id_shape(param)} module={debug_module2name(module)}"
                )
                if not param.is_cuda:
                    print_rank_0(
                        f"WARN: param {param_name} in module {module.__class__.__name__} "
                        f"expected to be on GPU but was on {param.device}", force=True)
                    # FIXME: tensors created with torch.FloatTensor is not wrapped
                    device = torch.device('cuda:{}'.format(os.environ["LOCAL_RANK"])) 
                    param.data = param.data.to(device)
                torch.distributed.broadcast(param, 0, group=self.ds_process_group)
                param.partition()
        see_memory_usage(
            f"Param count {param_count}. After converting and partitioning parmas in {module.__class__.__name__}",
            force=False)

    def _hierarchy_all_gather_params(self, params, param_buffers=None) -> AllGatherCoalescedHandle:
        """"""
        local_rank = int(os.environ["LOCAL_RANK"])
        inter_node_size = dist.get_world_size(group=self.inter_all_gather_group)
        intra_node_size = dist.get_world_size(group=self.intra_all_gather_group)
        param_tensors = []
        for i, p in enumerate(params):
            param_size = p.ds_tensor.ds_numel * self.ds_param_shard_size
            if param_buffers is not None and param_buffers[i] is not None:
                assert param_buffers[i].numel() == param_size, f'param_buffers[{i}] size {param_buffers[i].numel()} does not match with param_size {param_size}'
                param_tensor = param_buffers[i]
            else:
                param_tensor = torch.empty(
                    param_size,
                    dtype=p.dtype,
                    device=self.local_device,
                    requires_grad=False
                ).view(-1)
            param_tensors.append(param_tensor)

        # inter node all-gather
        inter_outputs = []
        inter_inputs = []
        for i, p in enumerate(params):
            inter_size = p.ds_tensor.ds_numel * inter_node_size
            _out = param_tensors[i].narrow(0, local_rank * inter_size, inter_size)
            inter_outputs.append(_out)
            inter_inputs.append(p.ds_tensor.data.view(-1))
        # sync enqueue
        c10d._all_gather_base_coalesced(
            inter_outputs,
            inter_inputs,
            group=self.inter_all_gather_group
        )

        # intra node all-gather
        intra_outputs = []
        intra_inputs = []
        for i, p in enumerate(params):
            # partition param into multiple chunks for allgather
            # because inter-node all-gather outputs are in a continues memory
            # while in param memory, those inter-node data are placed in different
            # location. 
            # each chunk is an intra-node output
            param_chunk = param_tensors[i].view((inter_node_size, intra_node_size, p.ds_tensor.ds_numel)).narrow(1, local_rank, 1)
            param_chunk.copy_(inter_outputs[i].detach().clone().view(param_chunk.size()))
            output_chunks = torch.chunk(param_tensors[i], inter_node_size)
            inter_chunks = torch.chunk(inter_outputs[i], inter_node_size)
            for j, _out in enumerate(output_chunks):
                intra_chunk_size = intra_node_size * p.ds_tensor.ds_numel 
                local_offset = local_rank * p.ds_tensor.ds_numel
                _in = param_tensors[i].narrow(0, j * intra_chunk_size + local_offset, p.ds_tensor.ds_numel)
                intra_outputs.append(_out)
                intra_inputs.append(_in)
        all_gather_handle = c10d._all_gather_base_coalesced(
            intra_outputs,
            intra_inputs,
            group=self.intra_all_gather_group,
            async_op=True
        )
        for i, param in enumerate(params):
            param.data = param_tensors[i].narrow(
                0, 0, param.ds_numel).view(param.ds_shape).data

        return AllGatherCoalescedHandle(
            handle=all_gather_handle,
            params=params,
            partitions=[],
            world_size=self.ds_param_shard_size,
            comm_stream=self.comm_stream,
            split_launch=True,
            launch_group=self.intra_all_gather_group
        )

    def _convert_to_deepspeed_param(self, param):

        # Partitioned, Normal, Remote
        param.ds_param_type = ZeroParamType.PARTITIONED

        # Replicated vs Partitioned vs Inflight
        param.ds_status = ZeroParamStatus.AVAILABLE

        # Stores the shape of the original tensor
        param.ds_shape = param.shape

        # Stores the number of elements in the original parameter without padding
        param.ds_numel = param.numel()

        # Stores the partitioned copy of the tensor
        param.ds_tensor = None

        # Keeps track of how many active sub-modules need this param at any given point in time
        param.ds_active_sub_modules = set()

        # If this flag is true, then the parameters are replicated throughput training
        # And only partitioned before the step
        param.ds_persist = False

        param.is_external_param = False

        # The group that the parameter is scattered across.
        param.ds_process_group = self.ds_process_group
        param.ds_param_shard_group = self.ds_param_shard_group
        param.ds_param_repli_group = self.ds_param_repli_group

        param.ds_param_shard_size = self.ds_param_shard_size 
        param.ds_param_repli_size = self.ds_param_repli_size

        # This is set to the Async Param swapper if remote device is nvme
        # else this is set to None
        param.nvme_swapper = self.param_swapper

        # DeepSped Param ID
        param.ds_id = Init.param_id
        Init.param_id += 1

        def all_gather(param_list=None, async_op=False, hierarchy=0, param_buffer=None):
            cls = param
            if param_list is None:
                param_list = [cls]
            if param_buffer is not None and not isinstance(param_buffer, (list, tuple)):
                param_buffer = [param_buffer]
            return self._all_gather(param_list, async_op=async_op, hierarchy=hierarchy, param_buffers=param_buffer)

        @instrument_w_nvtx
        def all_gather_coalesced(params, safe_mode=False, param_buffers=None) -> AllGatherCoalescedHandle:
            with torch.cuda.stream(torch.cuda.current_stream()):
                # fetches from nvme if the partition is not available and in nvme
                self._ensure_availability_of_partitioned_params(params)

                if param_buffers is not None:
                    assert len(param_buffers) == len(params), f'param_buffer size {len(param_buffers)} != params size {len(params)}.'

                params_to_gather = []
                params_to_gather_buffers = []
                if param_buffers is None:
                    param_buffers = [None] * len(params)
                for p, buf in filter(lambda x: x[0].ds_status == ZeroParamStatus.NOT_AVAILABLE,
                                     zip(params, param_buffers)):
                    p.ds_status = ZeroParamStatus.INFLIGHT
                    params_to_gather.append(p)
                    params_to_gather_buffers.append(buf)
                # ensure that each rank has params in same order. the allgather
                # is done by flattening the parameter list into a single tensor that
                # can be allgathered in a single call - this means that if each rank
                # gives a list of the same parameters in a different order we will
                # silently get incorrect parameter values, and have very difficult
                # to debug correctness issues.
                zipped_pairs = zip(params_to_gather, params_to_gather_buffers)
                sorted_pairs = sorted(zipped_pairs, key=lambda x: x[0].ds_id)
                sorted_tuples = zip(*sorted_pairs)
                params_to_gather, params_to_gather_buffers = [list(x) for x in sorted_tuples]

                if safe_mode:
                    # ensure that same list (with same ordering) of parameters are
                    # being allgathered across all ranks, otherwise could mix
                    # data between tensors.
                    assert_ints_same_as_other_ranks([p.ds_id for p in params_to_gather])
                    # ensure that tensors from each rank agree on the same ds_numel
                    # otherwise could mix data between tensors.
                    assert_ints_same_as_other_ranks(
                        [p.ds_tensor.ds_numel for p in params_to_gather])

                partition_sz = sum(p.ds_tensor.ds_numel for p in params_to_gather)

                data_types = set(p.dtype for p in params_to_gather)
                if len(data_types) != 1:
                    raise RuntimeError(
                        f"all tensors must have same dtype, got {data_types}")
                dtype, = data_types

                # for i, param in enumerate(params_to_gather):
                #     with open(f'/tmp/all_gather_rank{c10d.get_rank()}', 'a+') as log_out:
                #         log_out.write(f'{c10d.get_rank()}, {param.ds_id}, {param.ds_numel}, {param.ds_tensor.ds_numel}, {partition_sz}\n')

                if hasattr(c10d, '_all_gather_base_coalesced'):
                    # use _all_gather_base_coalesced
                    if self.hierarchy_allgather and self.ds_param_shard_size > 8:
                        return self._hierarchy_all_gather_params(params_to_gather, param_buffers=params_to_gather_buffers)

                    output_tensors = []
                    input_tensors = []
                    for i, p in enumerate(params_to_gather):
                        t_size = p.ds_tensor.ds_numel * self.ds_param_shard_size
                        if params_to_gather_buffers is not None and params_to_gather_buffers[i] is not None:
                            assert params_to_gather_buffers[i].numel() == t_size, f'params_to_gather_buffers[{i}] size {params_to_gather_buffers[i].numel()} does not match with t_size {t_size}'
                            flat_out = params_to_gather_buffers[i]
                        else:
                            flat_out = torch.empty(t_size,
                                                   dtype=dtype,
                                                   device=self.local_device,
                                                   requires_grad=False).view(-1)
                        output_tensors.append(flat_out)
                        input_tensors.append(p.ds_tensor.data.view(-1))

                    all_gather_handle = c10d._all_gather_base_coalesced(
                        output_tensors,
                        input_tensors,
                        group=self.ds_param_shard_group,
                        async_op=True)

                    for idx, param in enumerate(params_to_gather):
                        param.data = output_tensors[idx].narrow(0,
                                                                0,
                                                                param.ds_numel).view(
                                                                    param.ds_shape).data

                    return AllGatherCoalescedHandle(handle=all_gather_handle,
                                                    params=params_to_gather,
                                                    partitions=[],
                                                    world_size=self.ds_param_shard_size,
                                                    comm_stream=self.comm_stream,
                                                    split_launch=True,
                                                    launch_group=self.ds_param_shard_group)

                flat_tensor = torch.empty(partition_sz * self.ds_param_shard_size,
                                          dtype=dtype,
                                          device=self.local_device,
                                          requires_grad=False)

                # if _all_gather_base_coalesced not available
                partitions: List[Parameter] = []
                for i in range(self.ds_param_shard_size):
                    partitions.append(
                        flat_tensor.narrow(0,
                                           partition_sz * i,
                                           partition_sz))

                offset = 0
                shard_rank = dist.get_rank(group=self.ds_param_shard_group)

                for p in params_to_gather:
                    param_numel = p.ds_tensor.ds_numel
                    partitions[shard_rank].narrow(0,
                                                  offset,
                                                  param_numel).copy_(p.ds_tensor.data,
                                                                     non_blocking=True)
                    offset += param_numel

                all_gather_handle = instrument_w_nvtx(
                    torch.distributed._all_gather_base)(
                        flat_tensor,
                        partitions[shard_rank],
                        group=self.ds_param_shard_group,
                        async_op=True,
                    )

                return AllGatherCoalescedHandle(
                    handle=all_gather_handle,
                    params=params_to_gather,
                    partitions=partitions,
                    world_size=self.ds_param_shard_size,
                    comm_stream=self.comm_stream,
                )

        def partition(param_list=None, hierarchy=0, has_been_updated=False):
            cls = param
            print_rank_0(
                f"{'--'*hierarchy}----Partitioning param {debug_param2name_id_shape_device(cls)}"
            )
            if param_list is None:
                param_list = [cls]
            self._partition(param_list, has_been_updated=has_been_updated)

        @instrument_w_nvtx
        def reduce_gradients_at_owner(param_list=None, hierarchy=0):
            cls = param
            if param_list is None:
                param_list = [cls]
            print_rank_0(
                f"{'--'*hierarchy}----Reducing Gradients for param with ids {[param.ds_id for param in param_list]} to owner"
            )
            self._reduce_scatter_gradients(param_list)

        @instrument_w_nvtx
        def partition_gradients(param_list=None,
                                partition_buffers=None,
                                hierarchy=0,
                                accumulate=False):
            cls = param
            print_rank_0(
                f"{'--'*hierarchy}----Partitioning param gradient with id {debug_param2name_id_shape_device(cls)}"
            )
            if param_list is None:
                param_list = [cls]
                if isinstance(partition_buffers, torch.Tensor):
                    partition_buffers = [partition_buffers]

            self._partition_gradients(param_list,
                                      partition_buffers=partition_buffers,
                                      accumulate=accumulate)

        def aligned_size():
            return self._aligned_size(param)

        def padding_size():
            return self._padding_size(param)

        def partitioned_size():
            return self._partitioned_size(param)

        def ds_summary(slf: torch.Tensor) -> dict:
            return {
                "id": slf.ds_id,
                "status": slf.ds_status.name,
                "numel": slf.numel(),
                "ds_numel": slf.ds_numel,
                "shape": tuple(slf.shape),
                "ds_shape": tuple(slf.ds_shape),
                "requires_grad": slf.requires_grad,
                "grad_shape": tuple(slf.grad.shape) if slf.grad is not None else None,
                "persist": slf.ds_persist,
                "active_sub_modules": slf.ds_active_sub_modules,
            }

        # Collectives for gathering and partitioning parameters
        param.all_gather = all_gather
        param.all_gather_coalesced = all_gather_coalesced
        param.partition = partition

        # Collective for averaging gradients
        param.reduce_gradients_at_owner = reduce_gradients_at_owner
        param.partition_gradients = partition_gradients

        # Partitioning size utilities
        param.aligned_size = aligned_size
        param.padding_size = padding_size
        param.partitioned_size = partitioned_size
        param.ds_summary = types.MethodType(ds_summary, param)

    def _aligned_size(self, param):
        return param.ds_numel + self._padding_size(param)

    def _padding_size(self, param):
        remainder = param.ds_numel % self.ds_param_shard_size
        return (self.ds_param_shard_size - remainder) if remainder else 0

    def _partitioned_size(self, param):
        return param.ds_tensor.ds_numel

    def _ensure_availability_of_partitioned_params(self, params):
        swap_in_list = []
        swap_in_flight = []
        for param in params:
            if param.ds_tensor.status == PartitionedParamStatus.NOT_AVAILABLE:
                assert param.ds_tensor.final_location == OFFLOAD_NVME_DEVICE and param.ds_status == ZeroParamStatus.NOT_AVAILABLE
                swap_in_list.append(param)
            if param.ds_tensor.status == PartitionedParamStatus.INFLIGHT:
                assert param.ds_tensor.final_location == OFFLOAD_NVME_DEVICE and param.ds_status == ZeroParamStatus.NOT_AVAILABLE
                swap_in_flight.append(param)
        if len(swap_in_list) > 0:
            swap_in_list[0].nvme_swapper.swap_in(swap_in_list, async_op=False)
        elif len(swap_in_flight) > 0:
            swap_in_flight[0].nvme_swapper.synchronize_reads()

    @instrument_w_nvtx
    def _all_gather(self, param_list, async_op=False, hierarchy=None, param_buffers=None):

        if param_buffers is not None:
            assert len(param_list) == len(param_buffers), f'param_list size {len(param_list)} does not match with param_buffers size {len(param_buffers)}'
   
        #fetches from nvme if the partition is not available and in nvme
        self._ensure_availability_of_partitioned_params(param_list)

        handles = []
        all_gather_list = []
        for i, param in enumerate(param_list):
            if param.ds_status == ZeroParamStatus.NOT_AVAILABLE:
                if async_op:
                    param_buffer = None
                    if param_buffers is not None and param_buffers[i] is not None:
                        param_buffer = param_buffer
                    handle = self._allgather_param(param,
                                                   async_op=async_op,
                                                   hierarchy=hierarchy,
                                                   param_buffer=param_buffer)
                    param.ds_status = ZeroParamStatus.INFLIGHT  # if async_op else ZeroParamStatus.AVAILABLE
                    handles.append(handle)
                else:
                    all_gather_list.append(param)

        if not async_op:
            ret_value = self._allgather_params(all_gather_list, hierarchy=hierarchy, param_buffers=param_buffers)
            for param in all_gather_list:
                param.ds_status = ZeroParamStatus.AVAILABLE
            return ret_value

        return handles

    def _partition(self, param_list, force=False, has_been_updated=False):
        for param in param_list:
            #print_rank_0(f"Before Partitioning Param {param.ds_id}")
            #self._param_status(param)
            self._partition_param(param, has_been_updated=has_been_updated)
            #if param.ds_tensor is not None:
            #    assert id(param.data) == id(param.ds_tensor.data), \
            #    "After the parameters are initially partitioned, make sure we are not recreating the partition."
            #print_rank_0(f"After Partitioning Param {param.ds_id}")
            # self._param_status(param)

    @instrument_w_nvtx
    def _partition_param(self, param, buffer=None, has_been_updated=False):
        assert param.ds_status is not ZeroParamStatus.INFLIGHT, f" {param} Cannot parititon a param in flight"

        global reuse_buffers
        #print_rank_0(f"Param id {param.ds_id} status is {param.ds_status}")
        if param.ds_status is ZeroParamStatus.AVAILABLE:
            print_rank_0(
                f"Partitioning param id {param.ds_id} reuse buffers {reuse_buffers}",
                force=False)
            # if reuse_buffers and False:
            #     numel = buffer.numel()
            #     buffer = param.data.view(-1)
            #     print_rank_0(
            #         "Returning buffer for param {param.ds_id} with numel {param.ds_numel} to empty buffers",
            #         force=False)
            #     if numel in empty_buffers:
            #         empty_buffers[numel].append(buffer)

            #if torch.distributed.get_rank():
            #    print(f"Releasing {param.data.numel()}")
            if param.ds_tensor is not None and not has_been_updated:

                see_memory_usage(f"before partitioning {param.ds_summary()}")
                free_param(param)
                see_memory_usage(f"after partitioning {param.ds_summary()}")

                if param.ds_tensor.final_location == OFFLOAD_NVME_DEVICE:
                    print_rank_0(
                        f"Param {param.ds_id} partition released since it exists in nvme",
                        force=False)
                    param.nvme_swapper.remove_partition_and_release_buffers([param])

                return

            tensor_size = self._aligned_size(param)
            partition_size = tensor_size // self.ds_param_shard_size

            if param.ds_tensor is None:
                final_location = None
                if self.remote_device == OFFLOAD_NVME_DEVICE and self.param_swapper.swappable_tensor(
                        numel=partition_size):
                    final_location = OFFLOAD_NVME_DEVICE
                    buffer = self.param_swapper.get_buffer(param, partition_size)
                    partitioned_tensor = torch.empty(1,
                                                     dtype=param.dtype,
                                                     device=buffer.device)
                    partitioned_tensor.data = buffer.data
                    print_rank_0(
                        f"ID {param.ds_id} Initializing partition for the first time for nvme offload."
                    )

                else:
                    partitioned_tensor = torch.zeros(
                        partition_size,
                        # dtype=param.dtype,
                        dtype=self.dtype, # force all fp16 if the config enable fp16 or None
                        device=OFFLOAD_CPU_DEVICE
                        if self.remote_device == OFFLOAD_NVME_DEVICE else
                        self.remote_device)
                    if self.pin_memory:
                        partitioned_tensor = partitioned_tensor.pin_memory()

                partitioned_tensor.requires_grad = False
                param.ds_tensor = partitioned_tensor
                param.ds_tensor.ds_numel = partition_size
                param.ds_tensor.status = PartitionedParamStatus.AVAILABLE
                param.ds_tensor.final_location = final_location

                # print_rank_0(f"After partition param, param.shape{param.shape}, ds_shape{param.ds_shape} {debug_param2name_id_shape(param)}, {param.ds_tensor.size()}, {param.ds_tensor.dtype}", debug=True)

            shard_rank = dist.get_rank(group=self.ds_param_shard_group)
            start = partition_size * shard_rank
            end = start + partition_size

            one_dim_param = param.contiguous().view(-1)

            if start < param.ds_numel and end <= param.ds_numel:
                src_tensor = one_dim_param.narrow(0, start, partition_size)

                param.ds_tensor.copy_(src_tensor)
                #partitioned_tensor = src_tensor.clone().detach().to(self.remote_device)

            else:
                # partitioned_tensor = torch.zeros(partition_size,
                #                                  dtype=param.dtype,
                #                                  device=self.remote_device )

                if start < param.ds_numel:
                    elements_to_copy = param.ds_numel - start
                    param.ds_tensor.narrow(0,
                                           0,
                                           elements_to_copy).copy_(
                                               one_dim_param.narrow(
                                                   0,
                                                   start,
                                                   elements_to_copy))

            #print(f"Remote device {self.remote_device}")

            #param.ds_tensor = partitioned_tensor

            #param.data = param.ds_tensor.data

            #param.data does not store anything meaningful in partitioned state

            see_memory_usage(f'Before partitioning param {param.ds_id} {param.shape}',
                             force=False)
            free_param(param)
            see_memory_usage(f'After partitioning param {param.ds_id} {param.shape}',
                             force=False)

            if param.ds_tensor.final_location == OFFLOAD_NVME_DEVICE:
                self.param_swapper.swap_out_and_release([param])
                print_rank_0(
                    f"ID {param.ds_id} Offloaded to nvme offload and buffers released.")
                see_memory_usage(
                    f"ID {param.ds_id} Offloaded to nvme offload and buffers released.",
                    force=False)

            print_rank_0(
                f"ID {param.ds_id} partitioned type {param.dtype} dev {param.device} shape {param.shape}"
            )

    def _param_status(self, param):
        if param.ds_tensor is not None:
            print_rank_0(
                f"Param id {param.ds_id}, param status: {param.ds_status}, param numel {param.ds_numel}, partitioned numel {param.ds_tensor.numel()}, data numel {param.data.numel()}"
            )
        else:
            print_rank_0(
                f"Param id {param.ds_id}, param status: {param.ds_status}, param numel {param.ds_numel}, partitioned ds_tensor {param.ds_tensor}, data numel {param.data.numel()}"
            )

    @instrument_w_nvtx
    def _allgather_param(self, param, async_op=False, hierarchy=0, param_buffer=None):

        partition_size = param.ds_tensor.ds_numel

        tensor_size = partition_size * self.ds_param_shard_size
        aligned_param_size = self._aligned_size(param)
        assert tensor_size == aligned_param_size, f'param id {param.ds_id} aligned size {aligned_param_size} does not match tensor size {tensor_size}'

        print_rank_0(
            f"{'--'* hierarchy}---- Before allocating allgather param {debug_param2name_id_shape_status(param)} partition size={partition_size}"
        )

        see_memory_usage(
            f'Before allocate allgather param {debug_param2name_id_shape_status(param)} partition_size={partition_size} ',
            force=False)
        if param_buffer is not None:
            assert param_buffer.numel() == aligned_param_size, f'param_buffer size {param_buffer.numel()} does not match aligned_param_size {aligned_param_size}'
            flat_tensor = param_buffer
        else:
            flat_tensor = torch.empty(aligned_param_size,
                                      dtype=param.dtype,
                                      device=param.device).view(-1)

        see_memory_usage(
            f'After allocate allgather param {debug_param2name_id_shape_status(param)} {aligned_param_size} {partition_size} ',
            force=False)

        #torch.cuda.synchronize()

        print_rank_0(
            f"{'--'* hierarchy}----allgather param with {debug_param2name_id_shape_status(param)} partition size={partition_size}"
        )
        #        if not flat_tensor.numel() > 100000:
        #            replicated_tensor = flat_tensor.narrow(0,
        #                                                   0,
        #                                                   param.ds_numel).view(param.ds_shape)
        #            param.data = replicated_tensor.data
        #            return None
        partitions = []
        shard_rank = dist.get_rank(group=self.ds_param_shard_group)
        for i in range(self.ds_param_shard_size):
            partitions.append(flat_tensor.narrow(0, partition_size * i, partition_size))

            if i == shard_rank:
                partitions[i].data.copy_(param.ds_tensor.data, non_blocking=True)

        handle = torch.distributed.all_gather(partitions,
                                              partitions[shard_rank],
                                              group=self.ds_param_shard_group,
                                              async_op=async_op)

        replicated_tensor = flat_tensor.narrow(0, 0, param.ds_numel).view(param.ds_shape)
        param.data = replicated_tensor.data
        return handle

    def _allgather_params(self, param_list, hierarchy=0, param_buffers=None):
        if len(param_list) == 0:
            return

        partition_size = sum([param.ds_tensor.ds_numel for param in param_list])

        tensor_size = partition_size * self.ds_param_shard_size
        flat_tensor = torch.empty(tensor_size,
                                  dtype=param_list[0].dtype,
                                  device=self.local_device)
        flat_tensor.requres_grad = False
        partitions = []
        shard_rank = dist.get_rank(group=self.ds_param_shard_group)
        for i in range(self.ds_param_shard_size):
            start = partition_size * i

            partitions.append(flat_tensor.narrow(0, start, partition_size))

            if i == shard_rank:
                offset = 0
                for param in param_list:
                    param_numel = param.ds_tensor.ds_numel

                    partitions[i].narrow(0,
                                         offset,
                                         param_numel).copy_(param.ds_tensor.data)

                    offset += param_numel

        torch.distributed.all_gather(partitions,
                                     partitions[shard_rank],
                                     group=self.ds_param_shard_group,
                                     async_op=False)
        param_offset = 0

        for i, param in enumerate(param_list):
            param_partition_size = param.ds_tensor.ds_numel
            param_size = param.ds_numel
            if param_buffers is not None and param_buffers[i] is not None:
                replicated_tensor = param_buffers[i].narrow(0, 0, param_size).view(param.ds_shape)
            else:
                replicated_tensor = torch.empty(param.ds_shape,
                                                dtype=param.dtype,
                                                device=self.local_device)

            for i in range(self.ds_param_shard_size):

                start = i * partition_size

                param_start = i * param_partition_size

                if param_start < param_size:
                    numel_to_copy = min(param_size - param_start, param_partition_size)

                    part_to_copy = partitions[i].narrow(0, param_offset, numel_to_copy)

                    replicated_tensor.view(-1).narrow(0,
                                                      param_start,
                                                      numel_to_copy).copy_(part_to_copy)
            #param_offset += param.data.numel()
            param_offset += param.ds_tensor.ds_numel

            param.data = replicated_tensor.data

        return None
    
    @instrument_w_nvtx
    def __reduce_scatter_gradients_coalesced(self, param_list) -> List[Tuple]:
        """"""
        gradient_partitions_list: List[List[torch.Tensor]] = []
        coalesced_partition_size = 0
        for param in param_list:
            grad_partitions = []
            part_size = param.ds_tensor.ds_numel
            coalesced_partition_size += part_size

            for i in range(self.ds_param_shard_size):
                start = i * part_size
                end = start + part_size

                if start < param.ds_numel and end <= param.ds_numel:
                    grad_part = param.grad.view(-1).narrow(0, start, part_size)
                else:
                    grad_part = torch.zeros(part_size, dtype=param.dtype, device=param.device)
                    if start < param.ds_numel:
                        # copy data
                        nelem_remain = param.ds_numel - start
                        grad_part.narrow(0,0, nelem_remain).copy_(
                            param.grad.view(-1).narrow(0, start, nelem_remain))

                grad_partitions.append(grad_part)
            # append list     
            gradient_partitions_list.append(grad_partitions)

        if not hasattr(c10d, '_reduce_scatter_base'):
            raise RuntimeError("require _reduce_scatter_base API from torch c10d")
        else:
            arranged_inputs = [[gradient_partitions_list[param_idx][part_idx] 
                                for param_idx in range(len(param_list))]
                                    for part_idx in range(self.ds_param_shard_size)]
            reduce_scatter_input: torch.Tensor = torch.cat(list(itertools.chain(*arranged_inputs)))
            shard_rank = c10d.get_rank(group=self.ds_param_shard_group)
            rank_part = reduce_scatter_input.narrow(0, 
                                                    shard_rank * coalesced_partition_size,
                                                    coalesced_partition_size)
            c10d._reduce_scatter_base(rank_part, reduce_scatter_input, group=self.ds_param_shard_group)

            # remove this part
            # all_reduce at the gradient acc boundary
            # if self.local_shard and \
            #     c10d.get_world_size(group=self.ds_param_repli_group) > 1:
            #     c10d.all_reduce(rank_part, group=self.ds_param_repli_group)

            # narrow back to get the communicated results
            reduced_grads = []
            offset = 0
            for _, param in enumerate(param_list):
                part_size = param.ds_tensor.ds_numel
                reduced_grads.append(rank_part.narrow(0, offset, part_size))
                offset += part_size

            return zip([None] * len(param_list), reduced_grads)

    @instrument_w_nvtx
    def _reduce_scatter_gradients(self, param_list):
        #print_rank_0([param.grad for param in param_list])
        #assert any([param.grad is None for param in param_list]), "None gradients cannot be reduce scattered"

        # handles_and_reduced_partitions = []
        for param in param_list:
            if param.grad.numel() != param.ds_numel:
                raise RuntimeError(f"{param.grad.numel()} != {param.ds_numel}" 
                    "Cannot reduce scatter gradients whose size is not same as the params")

            # handles_and_reduced_partitions.append(self._reduce_scatter_gradient(param))
        handles_and_reduced_partitions = self.__reduce_scatter_gradients_coalesced(param_list)

        shard_rank = dist.get_rank(group=self.ds_param_shard_group)
        for param, (handle, reduced_partition) in zip(param_list, handles_and_reduced_partitions):
            if handle is not None:
                handle.wait()

            # some ranks may have partitions that are padded to go beyond the grad size.
            # For these ranks the output of reduce scatter is a separate buffer and needs
            # to be copied in
            partition_size = param.ds_tensor.ds_numel
            start = shard_rank * partition_size
            # end = start + partition_size
            # DONE: the reduce-scatter is not performed on the original grad tensor
            # need to copy the partition into grad tensor?
            if start < param.ds_numel:
                elements = min(param.ds_numel - start, param.ds_tensor.ds_numel)
                param.grad.view(-1).narrow(0,
                                           start,
                                           elements).copy_(
                                               reduced_partition.narrow(0,
                                                                        0,
                                                                        elements))

    @instrument_w_nvtx
    def _reduce_scatter_gradient(self, param):

        partition_size = param.ds_tensor.ds_numel
        #output = torch.empty(partition_size, dtype=param.dtype, device=param.device)

        input_list = []
        for i in range(self.ds_param_shard_size):

            start = i * partition_size
            end = start + partition_size

            #print("before reduce scatter gradients")
            if start < param.ds_numel and end <= param.ds_numel:
                input = param.grad.view(-1).narrow(0, start, partition_size)
            else:
                input = torch.zeros(partition_size,
                                    dtype=param.dtype,
                                    device=param.device)

                if start < param.ds_numel:
                    elements = param.ds_numel - start
                    input.narrow(0,
                                 0,
                                 elements).copy_(
                                     param.grad.view(-1).narrow(0,
                                                                start,
                                                                elements))
            #print("after reduce scatter gradients")
            input_list.append(input)

        rank = dist.get_rank(group=self.ds_param_shard_group)
        if not hasattr(c10d, '_reduce_scatter_base'):
            handle = dist.reduce_scatter(input_list[rank],
                                         input_list,
                                         group=self.ds_param_shard_group,
                                         async_op=True)
        else:
            handle = c10d._reduce_scatter_base(input_list[rank],
                                               torch.cat(input_list),
                                               group=self.ds_param_shard_group,
                                               async_op=True)

        # remove this; will do all-reduce at grad acc boundary 
        # if self.local_shard and dist.get_world_size(group=self.ds_param_repli_group) > 1:
        #     # do the all_reduce with sharded part
        #     handle.wait()
        #     handle = dist.all_reduce(input_list[rank],
        #                              group=self.ds_param_repli_group,
        #                              async_op=True)

        return handle, input_list[rank]

    @instrument_w_nvtx
    def _partition_gradients(self, param_list, partition_buffers=None, accumulate=False):
        if partition_buffers is None:
            partition_buffers = [None] * len(param_list)

        for param, partition_buffer in zip(param_list, partition_buffers):
            self._partition_gradient(param,
                                     partition_buffer=partition_buffer,
                                     accumulate=accumulate)

    @instrument_w_nvtx
    def _partition_gradient(self, param, partition_buffer=None, accumulate=False):
        #import pdb;pdb.set_trace()
        # param.grad=None
        # param.grad.test()
        info_rank_0(f"-partition grad for: {param.ds_summary()}")
        print_rank_0(
            f"Partitioning param {param.ds_id} gradient of size {param.grad.numel()} type {param.grad.dtype} part_size {param.ds_tensor.ds_numel}"
        )
        see_memory_usage("Before partitioning gradients", force=False)
        partition_size = param.ds_tensor.ds_numel

        if partition_buffer is None:
            assert not accumulate, "No buffer to accumulate to"
            partition_buffer = torch.zeros(partition_size,
                                           dtype=param.dtype,
                                           device=param.device)
        else:
            assert partition_buffer.numel() >= partition_size, f"The partition buffer size {partition_buffer.numel()} should match the size of param.ds_tensor {partition_size}"

        rank = dist.get_rank(group=self.ds_param_shard_group)
        start = partition_size * rank
        end = start + partition_size

        dest_tensor_full_buffer = partition_buffer.view(-1).narrow(0, 0, partition_size)

        #print("before partition gradients")
        if start < param.ds_numel:
            elements = min(param.ds_numel - start, partition_size)

            dest_tensor = dest_tensor_full_buffer.narrow(0, 0, elements)
            src_tensor = param.grad.view(-1).narrow(0, start, elements)

            # just copy the grad partition to the buffer
            if not accumulate:
                dest_tensor.copy_(src_tensor)

            # if source and destinatoin are on same device,
            # add to the provided buffer
            elif src_tensor.device == dest_tensor.device:
                with torch.cuda.nvtx.range('acc_add'):
                    dest_tensor.add_(src_tensor)

            # if source and destination are on different device, copy first to src
            # then add and move back to the destination. This seems to run faster
            # when src is gpu and dest is cpu
            # adding directly to cpu is very slow
            else:
                acc_tensor = torch.empty(src_tensor.numel(),
                                         dtype=param.dtype,
                                         device=param.device)

                acc_tensor.copy_(dest_tensor)
                acc_tensor.add_(src_tensor)
                dest_tensor.copy_(acc_tensor)

            # partition_buffer.view(-1).narrow(
            #     0,
            #     0,
            #     elements).copy_(param.grad.view(-1).narrow(0,
            #                                             start,
            #                                             elements))

        #print("after partition gradients")
        param.grad.record_stream(torch.cuda.current_stream())
        param.grad.data = dest_tensor_full_buffer.data
        see_memory_usage("After partitioning gradients", force=False)


class GatheredParameters:
    def __init__(self, params, modifier_rank=None, fwd_module=None, enabled=True):
        """A context that collects parameters that were partitioned via a
        :class:`deepspeed.zero.Init` context. The parameters are partitioned
        again upon exit.

        Args:
            params (``torch.nn.Parameter``): A single parameter or a list of parameters to collect.
                It's assumed that all parameters are zero params.
            modifier_rank (int, optional): If specified, this rank's parameter will be
                broadcasted on exit from the context. This argument is required if ``params`` are
                modified, so that all processes have a consistent view of the data. Defaults
                to ``None``.
            fwd_module (``torch.nn.Module``, optional): If specified, ``params`` will be
                registered as external parameters of ``fwd_module``. See :meth:`deepspeed.zero.register_external_parameter`.
            enabled (bool, optional): If ``False``, this context is a no-op. Defaults to ``True``.

        Important: Make sure to use ``modifier_rank`` that is not ``None`` (e.g. ``modifier_rank=0``)
        if you need the GPU memory allocated by gather to be released upon exit from the context manager.

        Examples
        ========

        #. Allocate a partitioned module, initialize its weight on rank 0, and update all
           processes.

            .. code-block:: python

                with deepspeed.zero.Init():
                    linear = torch.nn.Linear(1000,1000)

                with deepspeed.zero.GatheredParameters(linear.weight,
                                                       modifier_rank=0):
                    if torch.distributed.get_rank() == 0:
                        linear.weight.zero_()

                with deepspeed.zero.GatheredParameters(linear.weight,
                                                       modifier_rank=0):
                    if torch.distributed.get_rank() == 0:
                        linear.weight.zero_()

        #. Collect a partitioned weight to pass to another module during
           training. The parameter will be registered as an external parameter
           and made available during the backward pass.

            .. code-block:: python
                :emphasize-lines: 6

                def forward(self, input):
                    x = self.layer1(input)

                    # self.layer1.weight is required by self.layer2.forward
                    with deepspeed.zero.GatheredParameters(self.layer1.weight,
                                                           fwd_module=self):
                        y = self.layer2(x, self.layer1.weight)
                    return y


        #. Pretrained model loading

            .. code-block:: python

                with deepspeed.zero.Init():
                    model = MyModel()

                state_dict = torch.load(model_path, map_location="cpu")

                def load(module: nn.Module, prefix=""):
                    # because zero3 puts placeholders in model params, this context
                    # manager gathers (unpartitions) the params of the current layer, then loads from
                    # the state dict and then re-partitions them again
                    with deepspeed.zero.GatheredParameters(list(module.parameters(recurse=False)), modifier_rank=0):
                        if torch.distributed.get_rank() == 0:
                            module._load_from_state_dict(state_dict, prefix)

                    for name, child in module._modules.items():
                        if child is not None:
                            load(child, prefix + name + ".")

                load(model, prefix="")

        If this approach is not used, then the full model will first get copied to each GPU. For models
        bigger than the memory of a single gpu this method is required.
        """

        self.enabled = enabled
        if not enabled:
            return

        if not isinstance(params, list):
            params = [params]

        # enable if at least one is zero-param, otherwise a noop
        if not any(is_zero_param(p) for p in params):
            self.enabled = False
            return

        self.params = [p for p in params if hasattr(p, "ds_id")]
        self.src_rank = None
        if modifier_rank is not None:
            if self.params[0].ds_process_group == torch.distributed.group.WORLD:
                self.src_rank = modifier_rank
            else:
                # A group was specified; convert DP rank to global rank
                self.src_rank = _get_global_rank(self.params[0].ds_process_group,
                                                 modifier_rank)
        self.fwd_module = fwd_module
        if self.fwd_module is not None:
            # is a no-op if already registered
            for p in self.params:
                register_external_parameter(self.fwd_module, p)

    @instrument_w_nvtx
    def __enter__(self):
        if not self.enabled:
            return
        self.params[0].all_gather(param_list=self.params)

    @instrument_w_nvtx
    def __exit__(self, *exc):
        if not self.enabled:
            return
        if self.src_rank is None:
            return

        print("debug print calling from GatheredParameters.__exit__")
        handles = [
            torch.distributed.broadcast(p,
                                        self.src_rank,
                                        group=p.ds_process_group,
                                        async_op=True) for p in self.params
        ]
        for h in handles:
            h.wait()
        self.params[0].partition(param_list=self.params, has_been_updated=True)
