import os
import logging
from typing import List

import torch
import torch.distributed as dist
from deepspeed.utils import logger
from deepspeed.ops.adam import DeepSpeedCPUAdam
from deepspeed.ops.adam import FusedAdam
from deepspeed.utils.nvtx import instrument_w_nvtx


def _initialize_parameter_parallel_groups(parameter_parallel_size=None):
    data_parallel_size = int(dist.get_world_size())
    parameter_parallel_size = parameter_parallel_size or data_parallel_size
    logger.info("data_parallel_size: %s, parameter_parallel_size: %s",
                data_parallel_size,
                parameter_parallel_size)
    assert data_parallel_size % parameter_parallel_size == 0, \
        'world size should be divisible by parameter parallel size'
    rank = dist.get_rank()
    my_group = None
    for i in range(data_parallel_size // parameter_parallel_size):
        ranks = range(i * parameter_parallel_size, (i + 1) * parameter_parallel_size)
        group = torch.distributed.new_group(ranks)
        if rank in ranks:
            my_group = group
    return my_group


ZERO_SUPPORTED_OPTIMIZERS = [
    torch.optim.Adam,
    torch.optim.AdamW,
    FusedAdam,
    DeepSpeedCPUAdam
]

# Add apex FusedAdam to supported list if apex is installed
try:
    import apex
    if hasattr(apex, 'optimizers') and hasattr(apex.optimizers, 'FusedAdam'):
        ZERO_SUPPORTED_OPTIMIZERS.append(apex.optimizers.FusedAdam)
except ImportError:
    pass


def is_zero_supported_optimizer(optimizer):
    if dist.get_rank() == 0:
        logger.info(
            f'Checking ZeRO support for optimizer={optimizer.__class__.__name__} type={type(optimizer)}'
        )
    return type(optimizer) in ZERO_SUPPORTED_OPTIMIZERS


def get_lst_from_rank0(lst: List[int]) -> None:
    """
    NOTE: creates both communication and synchronization overhead so should be used
    sparingly
    """
    lst_tensor = torch.tensor(
        lst if dist.get_rank() == 0 else [-1] * len(lst),
        dtype=int,
        # device=torch.cuda.current_device(),
        device=torch.device('cuda:{}'.format(os.environ["LOCAL_RANK"])),
        requires_grad=False,
    )
    dist.broadcast(lst_tensor, src=0, async_op=False)

    return list(lst_tensor.cpu().numpy())


@instrument_w_nvtx
def assert_ints_same_as_other_ranks(ints: List[int]) -> None:
    """
    NOTE: creates both communication and synchronization overhead so should be
    used sparingly

    takes a list of ints from each rank and ensures that they are the same
    across ranks, throwing an exception if they are not.
    """
    rank0_ints = get_lst_from_rank0(ints)
    if ints != rank0_ints:
        raise RuntimeError(f"disagreement between rank0 and rank{dist.get_rank()}: "
                           f"rank0: {rank0_ints}, rank{dist.get_rank()}: {ints}")


class ZeRORuntimeException(Exception):
    pass

def assign_param_name(module: torch.nn.Module):
    for name, param in module.named_parameters(recurse=True):
        # print("has name", param.name)
        param.ds_name = name

def module_param_summary(module: torch.nn.Module) -> List[str] :
    vals = []
    for param in module.parameters(recurse=True):
        if hasattr(param, "ds_name") and hasattr(param, "ds_id"):
            vals.append(f'{param.ds_name}: shape {list(param.ds_shape)}/{list(param.ds_tensor.shape)}, param sum {torch.sum(param.data)}/{torch.sum(param.ds_tensor)}')
        elif hasattr(param, "ds_id"):
            vals.append(f'ds-id-{param.ds_id}: shape {list(param.ds_shape)}/{list(param.ds_tensor.shape)}, param sum {torch.sum(param.data)}/{torch.sum(param.ds_tensor)}')
        elif hasattr(param, "ds_name"):
            vals.append(f'{param.ds_name}: shape {list(param.shape)}, param sum {torch.sum(param.data)}')
        else:
            vals.append(f'<unknow param>: shape {list(param.shape)}, param sum {torch.sum(param.data)}')
    return vals

class DistFileLoggerFactory:
    @staticmethod
    def create_logger(name="ds-file-logger",level=logging.INFO):
        """create a logger

        Args:
            name (str): name of the logger
            level: level of logger

        Raises:
            ValueError is name is None
        """

        if name is None:
            raise ValueError("name for logger cannot be None")

        # must first initialized  
        assert dist.is_initialized()
        rank = dist.get_rank()
        local_idx = rank % torch.cuda.device_count()

        log_folder = f"/tmp/{name}"
        if not os.path.exists(log_folder) and local_idx == 0:
            os.makedirs(log_folder)
        dist.barrier()

        log_file = f"{log_folder}/rank-{rank}.log"

        formatter = logging.Formatter(
            "[%(levelname)s] "
            "[%(filename)s:%(lineno)d:%(funcName)s] %(message)s")

        logger_ = logging.getLogger(f"{name}-rank-{rank}")
        logger_.setLevel(level)
        logger_.propagate = False
        fh = logging.FileHandler(log_file)
        fh.setLevel(level)
        fh.setFormatter(formatter)
        logger_.addHandler(fh)
        return logger_
