import json
import argparse

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--nnodes', required=True, type=int)
    parser.add_argument('--ngpu-per-node', default=8, type=int, help="number of GPUs on one node")
    parser.add_argument('--shard-span', default=2, type=int, help="memory shard across <n> nodes")
    parser.add_argument('--output', required=True, help='output file location')

    args = parser.parse_args()

    config = {
        'shard_groups': [],
        'replicate_groups': [],
        'shard_span': args.shard_span
    }

    assert args.nnodes % args.shard_span == 0

    ranks = [i for i in range(args.nnodes * args.ngpu_per_node)]
    shard_size = args.shard_span * args.ngpu_per_node
    for i in range(args.nnodes // args.shard_span):
        start = i * shard_size
        end = start + shard_size
        config['shard_groups'].append(ranks[start:end])

    repli_size = args.nnodes // args.shard_span
    if repli_size > 1:
        for i in range(shard_size):
            repli_ranks = []
            for k in range(repli_size):
                repli_ranks.append(config['shard_groups'][k][i])
            config['replicate_groups'].append(repli_ranks)
    
    with open(args.output, 'w') as out_file:
        json.dump(config, out_file, indent=4)

if __name__ == "__main__":
    main()
